AddCSLuaFile()
player_manager.AddValidModel( "FAT_male07",  "models/player/group01/fatman.mdl" )
